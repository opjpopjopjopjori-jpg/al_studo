import fs from 'fs';
let text = fs.readFileSync('services/gemini.ts', 'utf8');
text = text.replaceAll('<!-- Right Column -->\n       <div class="mindmap-col" style="display: flex; flex-direction: column; gap: 20px; flex: 1; min-width: 150px; max-width: 200px; justify-content: center;">', '<!-- Right Column -->\n       <div class="mindmap-col" style="display: flex; flex-direction: column; gap: 20px; flex: 1; min-width: 180px; justify-content: center;">');
fs.writeFileSync('services/gemini.ts', text);
