export const formatSummary = async () => {
    let html = "test";
    html = html.replace(/^```html\s*/, '').replace(/```$/, '').trim();
    return html;
};
