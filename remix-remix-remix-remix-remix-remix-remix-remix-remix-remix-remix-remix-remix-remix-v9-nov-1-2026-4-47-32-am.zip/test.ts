const systemInstruction = `
function doGet() {
  var html = [
    '<script>',
    '  function onSuccess(data) {',
    '    var resHtml = "<p style=\\"color:green; font-size:18px;\\">✅ تم إنشاء الاختبار بنجاح!</p>";',
    '    resHtml += "<p><strong>رابط تعديل الاختبار (لك):</strong><br><a href=\\"" + data.editUrl + "\\" target=\\"_blank\\" style=\\"color:#1a73e8; word-break:break-all;\\">" + data.editUrl + "</a></p>";',
    '    resHtml += "<p><strong>رابط الاختبار للطلاب (نشر):</strong><br><a href=\\"" + data.publishedUrl + "\\" target=\\"_blank\\" style=\\"color:#1a73e8; word-break:break-all;\\">" + data.publishedUrl + "</a></p><br>";',
    '    resHtml += "<button onclick=\\"window.open(\\'" + data.publishedUrl + "\\', \\'_blank\\')\\" style=\\"padding:10px 20px; background:#34a853; color:white; border:none; border-radius:6px; cursor:pointer;\\">فتح الاختبار للطلاب</button>";',
    '    document.getElementById("result").innerHTML = resHtml;',
    '  }',
    '  function onError(error) {',
    '    document.getElementById("result").innerHTML = "<p style=\\"color:red;\\">❌ حدث خطأ: " + error.message + "</p>";',
    '    console.error(error);',
    '  }',
    '</script>'
  ].join("");
  return HtmlService.createHtmlOutput(html).setTitle("إنشاء اختبار").setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
`;
console.log(systemInstruction);
